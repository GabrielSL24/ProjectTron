﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project_Tron
{
    public partial class Form1 : Form
    {
        int cols = 30;
        int rows = 30;
        bool goLeft, goRight, goUp, goDown;
        public int trailSize = 3;
        private int fuelSize = 10;
        private int currentOIndex = 0;
        private bool isInvicible = false;
        private List<string> listdirections = new List<string> { "left", "up", "down", "right" };
        private string DirectionE1 = "right";
        private string DirectionE2 = "right";
        private string DirectionE3 = "right";
        private string DirectionE4 = "right";

        public List<Circle> Moto1 = new List<Circle>();
        private List<Circle> Enemigo1 = new List<Circle>();
        private List<Circle> Enemigo2 = new List<Circle>();
        private List<Circle> Enemigo3 = new List<Circle>();
        private List<Circle> Enemigo4 = new List<Circle>();
        private List<List<Circle>> ListEnemies = new List<List<Circle>>();
        private List<bool> combustibleList = new List<bool>(new bool[10]);
        private Powers power;
        private Items items;
        private Items itemsCombustible;

        private Circle head;
        private Circle cell = new Circle();
        private Circle speedBoost = new Circle();
        private Circle fuel = new Circle();
        private Circle bomb = new Circle();
        private Circle shield = new Circle();
        private Color orginalMoto;
        private Color originalE;
        private Color speedBoostColor = Color.LightCyan;
        private Color shieldColor = Color.Yellow;
        private Nodos currentNode;
        private Nodos currentNodeE1;
        private Nodos currentNodeE2;
        private Nodos currentNodeE3;
        private Nodos currentNodeE4;

        GridMap matriz = new GridMap();
        Random rand = new Random();
        Timer timer = new Timer();
        Timer enemyTimer = new Timer();
        Timer fuelTimer;


        public Form1()
        {
            InitializeComponent();
            new Nodos();
            power = new Powers(BoxPower1, BoxPower2, BoxPower3, ChangeSpeed, ApplyShield, Moto1);
            items = new Items(BoxItem1, BoxItem2, BoxItem3, ApplyItem, ApplyFuel, ApplyBomb);
            picCanvas.Paint += new PaintEventHandler(UpdatePictureBox);
            picCombustible.Paint += new PaintEventHandler(UpdateCombustible);

            fuelTimer = new Timer();
            fuelTimer.Interval = 6000;
            fuelTimer.Tick += FuelConsumptionEvent;
            fuelTimer.Start();
            timer.Interval = 100;
            enemyTimer.Interval = 100;
            timer.Tick += GameTimerEvent;
            enemyTimer.Tick += EnemyTimerEvent;
            timer.Start();
            enemyTimer.Start();
        }
        // Establece las direcciones de la Moto1 y que sea diferente al contrario cuando se presiona la tecla
        private void KeyIsDown(object sender, KeyEventArgs e)
        {

            if (e.KeyCode == Keys.Left && Nodos.directions != "right")
            {
                goLeft = true;
            }
            if (e.KeyCode == Keys.Right && Nodos.directions != "left")
            {
                goRight = true;
            }
            if (e.KeyCode == Keys.Up && Nodos.directions != "down")
            {
                goUp = true;
            }
            if (e.KeyCode == Keys.Down && Nodos.directions != "up")
            {
                goDown = true;
            }
            if (e.KeyCode == Keys.X)
            {
                power.SwapPowers();
            }
            if (e.KeyCode == Keys.Z)
            {
                if (power.powerStack1.Count > 0)
                {
                    Powers activepower = power.powerStack1.Peek(); //Obtener el poder arriba de la pila
                    power.ApplyPower(activepower);
                }
            }
        }
        //Cuando la tecla se deja de presionar hace estos eventos
        private void KeyIsUp(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Left)
            {
                goLeft = false;
            }
            if (e.KeyCode == Keys.Right)
            {
                goRight = false;
            }
            if (e.KeyCode == Keys.Up)
            {
                goUp = false;
            }
            if (e.KeyCode == Keys.Down)
            {
                goDown = false;
            }
        }
        //Función para el funcionamiento del Timer del PLayer
        private void GameTimerEvent(object sender, EventArgs e)
        {
            if (Moto1 == null || currentNode == null)
                return;

            if (goLeft)
            {
                Nodos.directions = "left";
            }
            if (goRight)
            {
                Nodos.directions = "right";
            }
            if (goUp)
            {
                Nodos.directions = "up";
            }
            if (goDown)
            {
                Nodos.directions = "down";
            }
            MoveMoto();
            picCanvas.Invalidate();
        }
        //Función para el funcionamiento del Timer del Enemigo
        private void EnemyTimerEvent(object sender, EventArgs e)
        {
            if (currentNodeE1 == null || currentNodeE2 == null || currentNodeE3 == null || currentNodeE4 == null || Enemigo1 == null || Enemigo2 == null || Enemigo3 == null || Enemigo4 == null)

            MoveEnemies(Enemigo1, currentNodeE1, ref DirectionE1);
            MoveEnemies(Enemigo2, currentNodeE2, ref DirectionE2);
            MoveEnemies(Enemigo3, currentNodeE3, ref DirectionE3);
            MoveEnemies(Enemigo4, currentNodeE4, ref DirectionE4);
            picCanvas.Invalidate();
        }

        private void MoveMoto()
        {
            for (int i = Moto1.Count - 1; i >= 0; i--)
            {
                if (i == 0)
                {
                    switch (Nodos.directions)
                    {
                        case "right":
                            if (Moto1[i].X < cols - 1 && currentNode.next != null)
                            {
                                currentNode = currentNode.next;
                                Moto1[i].X += 1;
                            }
                            break;
                        case "left":
                            if (Moto1[i].X > 0 && currentNode.previous != null)
                            {
                                currentNode = currentNode.previous;
                                Moto1[i].X -= 1;
                            }
                            break;
                        case "up":
                            if (Moto1[i].Y > 0 && currentNode.higher != null)
                            {
                                currentNode = currentNode.higher;
                                Moto1[i].Y -= 1;
                            }
                            break;
                        case "down":
                            if (Moto1[i].Y < rows - 1 && currentNode.bottom != null)
                            {
                                currentNode = currentNode.bottom;
                                Moto1[i].Y += 1;
                            }
                            break;
                    }

                    foreach (var enemy in ListEnemies)
                    {
                        for (int j = 0; j < enemy.Count; j++)
                        {
                            if (Moto1[i].X == enemy[j].X && Moto1[i].Y == enemy[j].Y)
                            {
                                if (isInvicible == false)
                                {
                                    GameOver();
                                }
                            }
                        }
                    }

                    if (Moto1[i].X == speedBoost.X && Moto1[i].Y == speedBoost.Y)
                    {
                        PickupSpeedBoost();
                    }

                    if (Moto1[i].X == cell.X && Moto1[i].Y == cell.Y)
                    {
                        PickupCelda();
                    }

                    if (Moto1[i].X == fuel.X && Moto1[i].Y == fuel.Y)
                    {
                        PickupFuel();
                    }

                    if (Moto1[i].X == bomb.X && Moto1[i].Y == bomb.Y)
                    {
                        PickupBomb();
                    }

                    if (Moto1[i].X == shield.X && Moto1[i].Y == shield.Y)
                    {
                        PickupShield();
                    }

                    for (int j = 1; j < Moto1.Count; j++)
                    {
                        if (Moto1[i].X == Moto1[j].X && Moto1[i].Y == Moto1[j].Y)
                        {
                            if (isInvicible == false)
                            {
                                GameOver();
                            }
                        }
                    }
                }
                else
                {
                    Moto1[i].X = Moto1[i - 1].X;
                    Moto1[i].Y = Moto1[i - 1].Y;
                }
            }
        }

        private void MoveEnemies(List<Circle> enemy, Nodos currentNodeE, ref string Direction)
        {
            for (int i = enemy.Count - 1; i >= 0; i--)
            {
                if (i == 0)
                {
                    switch (Direction)
                    {
                        case "right":
                            if (enemy[i].X < cols - 1 && currentNodeE.next != null)
                            {
                                enemy[i].X += 1;
                                currentNodeE = currentNodeE.next;
                            }
                            else
                            {
                                Direction = listdirections[rand.Next(listdirections.Count)];
                            }
                            break;
                        case "left":
                            if (enemy[i].X > 0 && currentNodeE.previous != null)
                            {
                                enemy[i].X -= 1;
                                currentNodeE = currentNodeE.previous;
                            }
                            else
                            {
                                Direction = listdirections[rand.Next(listdirections.Count)];
                            }
                            break;
                        case "up":
                            if (enemy[i].Y > 0)
                            {
                                enemy[i].Y -= 1;
                                currentNodeE = currentNodeE.higher;
                            }
                            else
                            {
                                Direction = listdirections[rand.Next(listdirections.Count)];
                            }
                            break;
                        case "down":
                            if (enemy[i].Y < rows - 1 && currentNodeE.bottom != null)
                            {
                                enemy[i].Y += 1;
                                currentNodeE = currentNodeE.bottom;
                            }
                            else
                            {
                                Direction = listdirections[rand.Next(listdirections.Count)];
                            }
                            break;
                    }

                    foreach (var moto in Moto1)
                    {
                        if (enemy[i].X == moto.X && enemy[i].Y == moto.Y)
                        {
                            bool collison = rand.Next(2) == 1;
                            if (collison)
                            {
                                enemy.Clear();
                                return;
                            }
                            else
                            {
                                Direction = listdirections[rand.Next(listdirections.Count)];
                            }
                        }
                    }

                    foreach (var otherEnemies in ListEnemies)
                    {
                        if (otherEnemies != enemy)
                        {
                            for (int j = 0; j < otherEnemies.Count; j++)
                            {
                                if (enemy[i].X == otherEnemies[j].X && enemy[i].Y == otherEnemies[j].Y)
                                {
                                    int probability = rand.Next(200);
                                    bool collison = probability < 20;
                                    if (collison)
                                    {
                                        otherEnemies.Clear();
                                        return;
                                    }
                                    else
                                    {
                                        Direction = listdirections[rand.Next(listdirections.Count)];
                                    }

                                }
                            }
                        }
                    }
                    if (enemy[i].X == speedBoost.X && enemy[i].Y == speedBoost.Y)
                    {
                        speedBoost = new Circle { X = 2000, Y = 2000 };
                        ChangeSpeed(rand.Next(1, 11), enemy);
                        Spawn_Objects("speedBoost");
                    }

                }
                else
                {
                    enemy[i].X = enemy[i - 1].X;
                    enemy[i].Y = enemy[i - 1].Y;
                }
            }
        }



        private void UpdatePictureBox(object sender, PaintEventArgs e)
        {
            Graphics canvas = e.Graphics;
            int cellSize = picCanvas.Width / cols;

            for (int i = 0; i < Moto1.Count; i++)
            {
                Brush colour = new SolidBrush(Moto1[i].Color);

                canvas.FillEllipse(colour, new Rectangle(
                    Moto1[i].X * cellSize,
                    Moto1[i].Y * cellSize,
                    cellSize, cellSize
                    ));
            }

            for (int i = 0; i < Enemigo1.Count; i++)
            {
                Brush colour = new SolidBrush(Enemigo1[i].ColorE);

                canvas.FillEllipse(colour, new Rectangle(
                    Enemigo1[i].X * cellSize,
                    Enemigo1[i].Y * cellSize,
                    cellSize, cellSize
                    ));
            }

            for (int i = 0; i < Enemigo2.Count; i++)
            {
                Brush colour = new SolidBrush(Enemigo2[i].ColorE);

                canvas.FillEllipse(colour, new Rectangle(
                    Enemigo2[i].X * cellSize,
                    Enemigo2[i].Y * cellSize,
                    cellSize, cellSize
                    ));
            }

            for (int i = 0; i < Enemigo3.Count; i++)
            {
                Brush colour = new SolidBrush(Enemigo3[i].ColorE);

                canvas.FillEllipse(colour, new Rectangle(
                    Enemigo3[i].X * cellSize,
                    Enemigo3[i].Y * cellSize,
                    cellSize, cellSize
                    ));
            }

            for (int i = 0; i < Enemigo4.Count; i++)
            {
                Brush colour = new SolidBrush(Enemigo4[i].ColorE);

                canvas.FillEllipse(colour, new Rectangle(
                    Enemigo4[i].X * cellSize,
                    Enemigo4[i].Y * cellSize,
                    cellSize, cellSize
                    ));
            }

            canvas.FillEllipse(Brushes.Blue, new Rectangle(
                cell.X * cellSize,
                cell.Y * cellSize,
                cellSize, cellSize
                ));

            canvas.FillEllipse(Brushes.DarkRed, new Rectangle(
                speedBoost.X * cellSize,
                speedBoost.Y * cellSize,
                cellSize, cellSize
                ));

            canvas.FillEllipse(Brushes.Green, new Rectangle(
                fuel.X * cellSize,
                fuel.Y * cellSize,
                cellSize, cellSize
                ));

            canvas.FillEllipse(Brushes.Black, new Rectangle(
                bomb.X * cellSize,
                bomb.Y * cellSize,
                cellSize, cellSize
                ));

            canvas.FillEllipse(Brushes.White, new Rectangle(
                shield.X * cellSize,
                shield.Y * cellSize,
                cellSize, cellSize
                ));

            Pen pen = new Pen(Color.Black);
            for (int i = 0; i < rows; i++)
            {
                for (int j = 0; j < cols; j++)
                {
                    int x = j * cellSize;
                    int y = i * cellSize;
                    e.Graphics.DrawRectangle(pen, x, y, cellSize, cellSize);
                }
            }
        }

        private void PickupCelda()
        {
            Items cellItem = new Items(BoxItem1, BoxItem2, BoxItem3, ApplyItem, ApplyFuel, ApplyBomb);
            cellItem.Type = Items.ItemType.Cell;
            items.PickupItem(cellItem);
            items.ExecuteItemAfterDelay();
            cell = new Circle { X = 2500, Y = 2500 };
            Spawn_Objects("cell");
        }

        private void ApplyItem(int newTrailSize)
        {
            trailSize = Math.Max(1, Math.Min(newTrailSize, 10));
            ConfigureEstela();
        }

        private void ApplyFuel(int newFuel)
        {
            fuelSize = Math.Max(1, Math.Min(fuelSize + newFuel, 10));
            UpdateFuelDisplay();
        }

        private void ApplyBomb()
        {
            GameOver();
        }

        private void ConfigureEstela()
        {
            while (Moto1.Count < trailSize)
            {
                Circle estela = new Circle();
                Moto1.Add(estela);
            }

            while (Moto1.Count > trailSize)
            {
                Moto1.RemoveAt(Moto1.Count - 1);
            }
        }

        public async void PickupShield()
        {
            Powers shieldpower = new Powers(Powers.PowerType.Shield);
            power.PickupPower(shieldpower);
            shield = new Circle { X = 2000, Y = 2000 };
            Spawn_Objects("shield");
        }

        public async void ApplyShield()
        {
            isInvicible = true;
            orginalMoto = Moto1[0].Color;
            ChangeMotoColor(shieldColor, Moto1);
            await Task.Delay(6000);
            isInvicible = false;
            ChangeMotoColor(orginalMoto, Moto1);
            picCanvas.Invalidate();
        }

        private void PickupPower(Powers power)
        {
            Powers newPower = new Powers(Powers.PowerType.SpeedBoost);
            power.PickupPower(newPower);
        }

        private void PickupSpeedBoost()
        {
            Powers speedBoostPower = new Powers(Powers.PowerType.SpeedBoost);
            power.PickupPower(speedBoostPower);
            speedBoost = new Circle { X = 1500, Y = 1500 };
            Spawn_Objects("speedBoost");
        }

        private void PickupBomb()
        {
            Items bombItem = new Items(BoxItem1, BoxItem2, BoxItem3, ApplyItem, ApplyFuel, ApplyBomb);
            bombItem.Type = Items.ItemType.Bomb;
            items.PickupItem(bombItem);
            items.ExecuteItemAfterDelay();
            bomb = new Circle { X = 4000, Y = 4000 };
            Spawn_Objects("bomb");

        }

        private void PickupFuel()
        {
            Items fuelItem = new Items(BoxItem1, BoxItem2, BoxItem3, ApplyItem, ApplyFuel, ApplyBomb);
            fuelItem.Type = Items.ItemType.Fuel;
            items.PickupItem(fuelItem);
            items.ExecuteItemAfterDelay();
            UpdateFuelDisplay();
            fuel = new Circle { X = 3500, Y = 3500 };
            Spawn_Objects("fuel");
        }

        private async void Spawn_Objects(string objeto)
        {
            await Task.Delay(5000);
            Circle newPosition = new Circle { X = rand.Next(3, cols), Y = rand.Next(3, rows) };

            switch (objeto)
            {
                case "speedBoost":
                    speedBoost = newPosition;
                    break;
                case "cell":
                    cell = newPosition;
                    break;
                case "fuel":
                    fuel = newPosition;
                    break;
                case "bomb":
                    bomb = newPosition;
                    break;
                case "shield":
                    shield = newPosition;
                    break;
            }
            picCanvas.Invalidate();
        }

        public async void ChangeSpeed(int newSpeed, List<Circle> user)
        {
            if (user == Moto1)
            {
                Nodos.PlayerSpeed = newSpeed;
                timer.Interval = Nodos.PlayerSpeed;
                orginalMoto = Moto1[0].Color;
                ChangeMotoColor(speedBoostColor, user);

                await ResetColorDelay(5000, user);
                timer.Interval = 100;
                ChangeMotoColor(orginalMoto, user);
            }
            else
            {
                Nodos.EnemySpeed = newSpeed;
                enemyTimer.Interval = Nodos.EnemySpeed;
                originalE = user[0].Color;
                ChangeMotoColor(speedBoostColor, user);

                await ResetColorDelay(5000, user);
                enemyTimer.Interval = 100;
                ChangeMotoColor(originalE, user);
            }
            picCanvas.Invalidate();
        }

        private void ChangeMotoColor(Color color, List<Circle> user)
        {
            if (user == Moto1)
            {
                for (int i = 0; i < Moto1.Count; i++)
                {
                    Moto1[i].Color = color;
                }
            }
            else
            {
                for (int i = 0; i < user.Count; i++)
                {
                    user[i].ColorE = color;
                }
            }
            picCanvas.Invalidate();
        }

        private async Task ResetColorDelay(int delay, List<Circle> user)
        {
            if (user == Moto1)
            {
                await Task.Delay(delay);
                ChangeMotoColor(orginalMoto, user);
            }
            else
            {
                await Task.Delay(delay);
                ChangeMotoColor(originalE, user);
            }
        }

        public void UpdateFuelDisplay()
        {
            for (int i =0; i< combustibleList.Count; i++)
            {
                combustibleList[i] = i < fuelSize;
            }
            picCombustible.Invalidate();
        }

        private void UpdateCombustible(object sender, PaintEventArgs e)
        {
            Graphics g = e.Graphics;
            int totalCell = 10;
            int widthcell = picCombustible.Width / totalCell;
            int heightcell = picCombustible.Height;

            for (int i = 0; i < totalCell; i++)
            {
                if (combustibleList[i])
                {
                    g.FillRectangle(Brushes.Green, i * widthcell, 0, widthcell, heightcell);
                }
                else
                {
                    g.FillRectangle(Brushes.Red, i * widthcell, 0, widthcell, heightcell);
                }
                g.DrawRectangle(Pens.Black, i * widthcell, 0, widthcell, heightcell);
            }
        }

        private void FuelConsumptionEvent(object sender, EventArgs e)
        {
            if (fuelSize > 0)
            {
                fuelSize -= 1;
                UpdateFuelDisplay();
            }
            else
            {
                GameOver();
            }
        }

        private void StartGame(object sender, EventArgs e)
        {
            RestartGame();
            picCanvas.Invalidate();
        }

        private void RestartGame()
        {
            Moto1.Clear();
            Enemigo1.Clear();
            Enemigo2.Clear();
            Enemigo3.Clear();
            Enemigo4.Clear();

            StartButton.Enabled = false;
            matriz.CreateMatrix(rows, cols);
            power.ResetPowers();
            items.ResetItems();

            Circle headE1 = new Circle { X = 0, Y = 10, Color = Color.Lime };
            Circle headE2 = new Circle { X = 0, Y = 15, Color = Color.DarkBlue };
            Circle headE3 = new Circle { X = 0, Y = 20, Color = Color.Orange };
            Circle headE4 = new Circle { X = 0, Y = 25, Color = Color.Purple };
            Enemigo1.Add(headE1);
            Enemigo2.Add(headE2);
            Enemigo3.Add(headE3);
            Enemigo4.Add(headE4);


            Circle head = new Circle { X = 0, Y = 0 };
            Moto1.Add(head);

            for (int i = 0; i < 3; i++)
            {
                Circle estela = new Circle();
                Moto1.Add(estela);
            }
            for (int i = 0;i < 3;i++)
            {
                Circle estelaE1 = new Circle();
                Circle estelaE2 = new Circle();
                Circle estelaE3 = new Circle();
                Circle estelaE4 = new Circle();
                Enemigo1.Add(estelaE1);
                Enemigo2.Add(estelaE2);
                Enemigo3.Add(estelaE3);
                Enemigo4.Add(estelaE4);

            }
            fuelSize = 10;
            UpdateFuelDisplay();

            matriz.matriz[0, 0].value = 2;
            matriz.matriz[0,10].value = 3; //Enemigo1
            matriz.matriz[0,15].value = 4; //Enemigo2
            matriz.matriz[0,20].value = 5; //Enemigo3
            matriz.matriz[0,25].value = 6; //Enemigo4

            ListEnemies.Add(Enemigo1);
            ListEnemies.Add(Enemigo2);
            ListEnemies.Add(Enemigo3);
            ListEnemies.Add(Enemigo4);

            currentNode = matriz.matriz[0, 0];
            currentNodeE1 = matriz.matriz[0, 10];
            currentNodeE2 = matriz.matriz[0, 15];
            currentNodeE3 = matriz.matriz[0, 20];
            currentNodeE4 = matriz.matriz[0, 25];

            cell = new Circle { X = rand.Next(2, cols), Y = rand.Next(2, rows) };
            speedBoost = new Circle { X = rand.Next(2, cols), Y = rand.Next(2, rows) };
            fuel = new Circle { X = rand.Next(2, cols), Y = rand.Next(2, rows) };
            bomb = new Circle { X = rand.Next(2, cols), Y = rand.Next(2, rows) };
            shield = new Circle { X = rand.Next(2, cols), Y = rand.Next(2, rows) };

            Items itemsCombustible = new Items(picCombustible,this);
            timer.Interval = 100;
            enemyTimer.Interval = 100;
            enemyTimer.Start();
            timer.Start();

            picCanvas.Invalidate();
        }

        public void GameOver ()
        {
            timer.Stop();
            enemyTimer.Stop();
            fuelTimer.Stop();
            StartButton.Enabled = true;
        }
    }
}
