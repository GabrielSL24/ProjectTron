﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project_Tron
{
    class Powers
    {
        public enum PowerType { SpeedBoost, Shield}
        public PowerType Type { get; set; }
        private Action<int, List<Circle>> ChangeSpeedA;
        private Action ApplyShield;

        private int speedBoostValue;
        Random rand = new Random();

        public Stack<Powers> powerStack1 = new Stack<Powers>();
        public Stack<Powers> powerStack2 = new Stack<Powers>();
        public Stack<Powers> powerStack3 = new Stack<Powers>();
        private List<Circle> listPlayer;
        private PictureBox BoxPower1;
        private PictureBox BoxPower2;
        private PictureBox BoxPower3;

        public Powers(PictureBox box1, PictureBox box2, PictureBox box3, Action<int, List<Circle>> changeSpeedA, Action applyshield, List<Circle> list)
        {
            BoxPower1 = box1;
            BoxPower2 = box2;
            BoxPower3 = box3;
            this.ChangeSpeedA = changeSpeedA;
            this.ApplyShield = applyshield;
            this.listPlayer = list;
        }

        public Powers(PowerType type)
        {
            Type = type;
            if (type == PowerType.SpeedBoost)
            {
                speedBoostValue = rand.Next(1, 11);
            }
        }

        public int GetSpeedBoost()
        {
            return speedBoostValue;
        }

        public void PickupPower(Powers power)
        {
            if (powerStack1.Count == 0)
            {
                powerStack1.Push(power);
            }
            else if (powerStack2.Count == 0)
            {
                powerStack2.Push(power);
            }
            else if (powerStack3.Count == 0)
            {
                powerStack3.Push(power);
            }
            else
            {
                powerStack1.Push(power);
            }
            UpdatePower();
        }

        public void SwapPowers()
        {
            if (powerStack1.Count > 0 && powerStack2.Count > 0 && powerStack3.Count > 0)
            {
                Powers temp = powerStack1.Pop();
                powerStack1.Push(powerStack2.Pop());
                powerStack2.Push(powerStack3.Pop());
                powerStack3.Push(temp);
            }
            //Caso stack 1 vacio
            else if (powerStack1.Count == 0 && powerStack2.Count > 0 && powerStack3.Count > 0)
            {
                powerStack1.Push(powerStack2.Pop());
                powerStack2.Push(powerStack3.Pop());
            }
            //caso stack 2 vacio
            else if (powerStack2.Count == 0 && powerStack1.Count > 0 && powerStack3.Count > 0)
            {
                powerStack2.Push(powerStack3.Pop());
                powerStack3.Push(powerStack1.Pop());
            }
            //caso stack 3 vacio
            else if (powerStack3.Count == 0 && powerStack1.Count > 0 && powerStack2.Count > 0)
            {
                powerStack3.Push(powerStack1.Pop());
                powerStack1.Push(powerStack2.Pop());
            } 
            //si el stack 1 y stack 2 si y el stack 3 no
            else if (powerStack1.Count > 0 && powerStack2.Count > 0 && powerStack3.Count == 0)
            {
                Powers temp = powerStack1.Pop();
                powerStack1.Push(powerStack2.Pop());
                powerStack2.Push(temp);
            }
            // si el stack 1 y stack 3 si y el stack 2 no
            else if (powerStack1.Count > 0 && powerStack2.Count == 0 && powerStack3.Count > 0)
            {
                Powers temp = powerStack1.Pop();
                powerStack1.Push(powerStack3.Pop());
                powerStack3.Push(temp);
            }
            // si el stack 2 y el stack 3 si y el stack 1 no
            else if (powerStack1.Count == 0 && powerStack2.Count > 0 && powerStack3.Count > 0)
            {
                powerStack1.Push(powerStack2.Pop());
                powerStack2.Push(powerStack3.Pop());
            }
            //caso si 2 si y stack 1 y stack 3 no
            else if (powerStack2.Count > 0 && powerStack1.Count == 0 && powerStack3.Count == 0)
            {
                powerStack1.Push(powerStack2.Pop());
            }
            else if (powerStack3.Count > 0 && powerStack1.Count == 0 && powerStack2.Count == 0)
            {
                powerStack1.Push(powerStack3.Pop());
            }
            UpdatePower();
        }

        public void UpdatePower()
        {
            BoxPower1.Image = null;
            BoxPower2.Image = null;
            BoxPower3.Image = null;

            if (powerStack1.Count > 0)
            {
                BoxPower1.Image = DrawPowers(powerStack1.Peek().ToString());
            }
            if (powerStack2.Count > 0)
            {
                BoxPower2.Image = DrawPowers(powerStack2.Peek().ToString());
            }
            if (powerStack3.Count > 0)
            {
                BoxPower3.Image = DrawPowers(powerStack3.Peek().ToString());
            }

            BoxPower1.Refresh();
            BoxPower2.Refresh();
            BoxPower3.Refresh();
        }

        public void ApplyPower(Powers power)
        {
            switch (power.Type)
            {
                case Powers.PowerType.SpeedBoost:
                    int newSpeed = rand.Next(1, 11);
                    ChangeSpeedA.Invoke(newSpeed, listPlayer);
                        break;
                case Powers.PowerType.Shield:
                    ApplyShield();
                    break;
            }
            powerStack1.Pop();
            UpdatePower();
        }

        public Image DrawPowers(string text)
        {
            Bitmap bitmap = new Bitmap(BoxPower1.Width, BoxPower1.Height);
            using (Graphics g =  Graphics.FromImage(bitmap))
            {
                g.Clear(Color.White);
                g.DrawString(text, new Font("Arial", 16), Brushes.Black, new PointF(10, 10));
            }
            return bitmap;
        }

        public void ResetPowers()
        {
            powerStack1.Clear();
            powerStack2.Clear();
            powerStack3.Clear();
            UpdatePower();
        }
    }
}
