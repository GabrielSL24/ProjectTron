﻿using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project_Tron
{
    public class Circle
    {
        public Nodos CurrentNode {  get; set; }
        public int X {  get; set; }
        public int Y { get; set; }
        public string Direction { get; set; }
        public Color Color { get; set; } = Color.Cyan;
        public Color ColorE { get; set; } = Color.Red;
    }
}
