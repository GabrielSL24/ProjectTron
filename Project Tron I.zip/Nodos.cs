﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project_Tron
{
    public class Nodos
    {
        public Nodos next;
        public Nodos previous;
        public Nodos higher;
        public Nodos bottom;

        public int value;
        public static string directions;
        public string directionsE { get; set; }
        private static int _playerSpeedLevel;
        private static int _enemySpeedLevel;


        public static int PlayerSpeed
        {
            get
            {
                return 300 / _playerSpeedLevel;
            }
            set
            {
                if (value >= 1 && value <=10)
                {
                    _playerSpeedLevel = value;
                }
                else
                {
                    _playerSpeedLevel = 3;
                }
            }
        }

        public static int EnemySpeed
        {
            get
            {
                return 300 / _enemySpeedLevel;
            }
            set
            {
                if (value >= 1 && value <=10)
                {
                    _enemySpeedLevel = value;
                }
                else
                {
                    _enemySpeedLevel = 3;
                }    
            }
        }

        public Nodos ()
        {
            
            directions = "right";
            directionsE = "right";
            PlayerSpeed = 3;
            EnemySpeed = 3;
            next = null;
            previous = null;
            higher = null;
            bottom = null;
            value = 0;

        }
            
    }
}
