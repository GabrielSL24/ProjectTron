﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project_Tron
{
    public class GridMap
    {
        public Nodos[,] matriz { get; set; }

        

        public void CreateMatrix (int row, int column)
        {
            matriz = new Nodos[row, column];

            for (int i = 0; i < row; i++)
            {
                for (int j = 0; j < column; j++)
                {
                    matriz[i, j] = new Nodos();
                }
            }

            for (int i = 0; i < row; i++)
            {
                for (int j = 0; j < column; j++)
                {
                    if (i > 0)
                    {
                        matriz[i, j].higher = matriz[i - 1, j];
                    }
                    if (i < row - 1)
                    {
                        matriz[i, j].bottom = matriz[i + 1, j];
                    }
                    if (j > 0)
                    {
                        matriz[i, j].previous = matriz[i, j - 1];
                    }
                    if (j < column - 1)
                    {
                        matriz[i, j].next = matriz[i, j + 1];
                    }
                }
            }
        }
    }
}
