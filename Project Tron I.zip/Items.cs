﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Project_Tron
{
    class Items
    {
        public enum ItemType { Cell, Fuel, Bomb }
        public ItemType Type { get; set; }

        private Action<int> applyItemAction;
        private Action<int> applyItFuel;
        private Action applyItBomb;
        private Random rand = new Random();

        private Queue<Items> itemsQueue1 = new Queue<Items>();
        private Queue<Items> itemsQueue2 = new Queue<Items>();
        private Queue<Items> itemsQueue3 = new Queue<Items>();

        private PictureBox Boxitem1;
        private PictureBox Boxitem2;
        private PictureBox Boxitem3;
        private PictureBox picCombustible;
        private int fuelLevel = 10;
        private int fuelSize = 10;

        private Form1 form;

        public Items(PictureBox box1,  PictureBox box2, PictureBox box3, Action<int> applyItemAction, Action<int> applyItFuel, Action applyItBomb)
        {
            Boxitem1 = box1;
            Boxitem2 = box2;
            Boxitem3 = box3;
            this.applyItemAction = applyItemAction;
            this.applyItFuel = applyItFuel;
            this.applyItBomb = applyItBomb;
        }

        public Items(PictureBox picCombustible, Form1 form1)
        {
            this.picCombustible = picCombustible;
            form = form1;
        }

        public void PickupItem(Items item)
        {
            if (itemsQueue1.Count == 0)
            {
                itemsQueue1.Enqueue(item);
                UpdateItemDisplay(Boxitem1, item);
            }
            else if (itemsQueue2.Count == 0)
            {
                itemsQueue2.Enqueue(item);
                UpdateItemDisplay(Boxitem2, item);
            }
            else if (itemsQueue3.Count == 0)
            {
                itemsQueue3.Enqueue(item);
                UpdateItemDisplay(Boxitem3, item);
            }
        }

        public void UpdateItemDisplay(PictureBox box, Items item)
        {
            switch (item.Type)
            {
                case ItemType.Cell:
                    box.Image = null;
                    box.BackColor = Color.Blue;
                    box.Text = "Cell";
                    break;
                case ItemType.Fuel:
                    box.Image = null;
                    box.BackColor = Color.Green;
                    box.Text = "Fuel";
                    break;
                case ItemType.Bomb:
                    box.Image = null;
                    box.BackColor = Color.Black;
                    box.Text = "Bomb";
                    break;
            }
            box.Invalidate();
        }

        private void ClearItemDisplay(PictureBox box)
        {
            box.Image = null;
            box.BackColor = Color.Transparent;
            box.Text = "";
            box.Invalidate();
        }

        public async void ExecuteItemAfterDelay()
        {
            Items item = itemsQueue1.Peek();

            await Task.Delay(5000);

            if (item.Type == ItemType.Cell)
            {
                applyItemAction?.Invoke(rand.Next(1, 11));
            }
            else if (item.Type == ItemType.Fuel)
            {
                applyItFuel?.Invoke(rand.Next(1, 11));
            }
            else if (item.Type == ItemType.Bomb)
            {
                applyItBomb?.Invoke();
            }

            if (itemsQueue1.Count > 0)
            {
                itemsQueue1.Dequeue();
            }
            ClearItemDisplay(Boxitem1);

            if (itemsQueue2.Count > 0)
            {
                Items nextItem = itemsQueue2.Dequeue();
                itemsQueue1.Enqueue(nextItem);
                UpdateItemDisplay(Boxitem1, nextItem);

                if (itemsQueue3.Count > 0)
                {
                    Items thirdItem = itemsQueue3.Dequeue();
                    itemsQueue3.Enqueue(thirdItem);
                    UpdateItemDisplay(Boxitem2, thirdItem);

                    ClearItemDisplay(Boxitem3 );
                }
                else
                {
                    ClearItemDisplay(Boxitem2);
                }
            }
        }

        public void ResetItems()
        {
            itemsQueue1.Clear();
            itemsQueue2.Clear();
            itemsQueue3.Clear();

            ClearItemDisplay(Boxitem1);
            ClearItemDisplay(Boxitem2);
            ClearItemDisplay(Boxitem3);
        }
    }
}
